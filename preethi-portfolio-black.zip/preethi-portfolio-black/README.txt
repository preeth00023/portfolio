Open index.html in any browser. Fonts load from Google Fonts, so connect to the internet the first time.
Colors are at the top of index.html under :root if you want to change them.
